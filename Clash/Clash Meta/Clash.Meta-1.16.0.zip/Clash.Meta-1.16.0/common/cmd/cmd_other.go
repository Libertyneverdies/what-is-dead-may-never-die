//go:build !windows

package cmd

import (
	"os/exec"
)

func prepareBackgroundCommand(cmd *exec.Cmd) {

}
