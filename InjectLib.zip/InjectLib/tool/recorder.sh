tccutil reset Camera com.mac.utility.screen.recorder
tccutil reset Microphone com.mac.utility.screen.recorder
tccutil reset ScreenCapture com.mac.utility.screen.recorder